#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <string>
#include <string_view>
#include <vector>
#include "constants.h"
#include "converter.h"
#include "exception.h"
#include "secure_buffer.h"
#include "utils.h"


using json = nlohmann::json;

namespace
{

using MagicIdentifer = protocol::MagicIdentifer;


auto iso8601_to_unix(const std::string& iso8601) -> std::time_t
{
    std::string truncated = iso8601;

    // Remove fractional seconds if present
    auto dot_pos = truncated.find('.');
    if (dot_pos != std::string::npos) {
        truncated = truncated.substr(0, dot_pos) + "Z";
    }

    std::tm time{};
    std::istringstream iso_time(truncated);
    iso_time >> std::get_time(&time, "%Y-%m-%dT%H:%M:%SZ");

    if (iso_time.fail()) {
        throw Exception("Failed to convert iso8601 to unix time.\n",
                        Exception::ExceptionType::BitwardenConversionError);
    }

#ifdef _WIN32
    return _mkgmtime(&time);  // Windows
#else
    return timegm(&time);     // POSIX
#endif
}

template <typename T>
void append_magic_and_data(MagicIdentifer identifier, T&& data, std::vector<std::byte>& buffer)
{
  
  back_insert_vec(buffer, static_cast<uint8_t>(identifier));
  back_insert_vec(buffer, static_cast<uint16_t>(sizeof(data)));
  back_insert_vec(buffer, data);
}


void append_magic_and_data(MagicIdentifer identifier, std::string&& data, std::vector<std::byte>& buffer)
{
  // first byte for the magic identifier
  back_insert_vec(buffer, static_cast<uint8_t>(identifier));
  // next two bytes for the length of the data
  back_insert_vec(buffer, static_cast<uint16_t>(data.size()));
  // then the actual data
  back_insert_vec(buffer, data);
}


// using an overload to preventr the compiler complaining from nullptr existing in the back_inster_vec
void append_magic_and_data(MagicIdentifer identifier, std::nullptr_t data, std::vector<std::byte>& buffer)
{
  back_insert_vec(buffer, static_cast<uint8_t>(identifier));
  // a nullptr is used for a generic no data
  // this means we will just append a length of 0 and move on
  back_insert_vec(buffer, static_cast<uint16_t>(0));
}


auto append_if_not_null (std::string_view field, MagicIdentifer identifier, const json& item, std::vector<std::byte>& buffer) -> void{

  if (!item[field].is_null())
  {
    if (identifier == MagicIdentifer::DateCreated || identifier == MagicIdentifer::DateModified)
    {
        std::time_t unix_time{ iso8601_to_unix(static_cast<std::string>(item[field])) };
        append_magic_and_data(identifier, unix_time, buffer);               
    }
    else
    {
      append_magic_and_data(identifier, static_cast<std::string>(item[field]), buffer);               
    }
  }
  else{
    append_magic_and_data(identifier, nullptr, buffer);               
  }

};

void json_parser(const json& passwords, std::vector<std::byte>& buffer)
{

  for (const auto& item : passwords["items"])
  {

    if (!item.contains("type"))
    {
      throw Exception("Json given is not in a valid bitwarden export format.\n", Exception::ExceptionType::BitwardenConversionError);
    }

    const int item_type{item["type"]};
    
    // an item type of 1 refers to a password entry
    if (item_type != 1){ continue; }
  
    if (!item.contains("name") ||
        !item.contains("creationDate") ||
        !item.contains("revisionDate") ||
        !item.contains("notes") ||
        !item.contains("login"))
    { continue; }

    const json& login_info{item["login"]};

    if (!item["login"].contains("username") || !item["login"].contains("password"))
    {
      continue;
    }

    buffer.push_back(static_cast<std::byte>(MagicIdentifer::Initial));
    
    append_if_not_null("name", MagicIdentifer::Site, item, buffer);      
    append_if_not_null("notes", MagicIdentifer::Note, item, buffer);

    append_if_not_null("creationDate", MagicIdentifer::DateCreated, item, buffer);
    append_if_not_null("revisionDate", MagicIdentifer::DateModified, item, buffer);

    append_if_not_null("username", MagicIdentifer::Username, login_info, buffer); 
    append_if_not_null("password", MagicIdentifer::Password, login_info, buffer);      
    
  }
}
  
}// unnamed namespace


// the use of a secure buffer is meant purely from a convience standpoint for the rest of the code
// due to the nature of a publicly accessible unencrypted file, security is not of a great concern
// additionally this does not include the front headers
auto convert_from_bitwarden_json(const fs::path& json_path) -> SecureBuffer
{
  if (json_path.extension() != ".json")
  {
    throw Exception("File given is not a json.\n", Exception::ExceptionType::BitwardenConversionError);
  }

  std::ifstream file{json_path};

  if (!file.is_open())
  {
    throw Exception("Failed to open bitwarden json.\n", Exception::ExceptionType::BitwardenConversionError);
  }

  std::vector<std::byte> buffer;

  json passwords;

  try
  {
    file >> passwords;  
  }
  catch (json::parse_error& e)
  {
    throw Exception("Failed to parse given json.\n", Exception::ExceptionType::BitwardenConversionError);
  }

  if (!passwords.contains("items"))
  {
    throw Exception("Json given is not in a valid bitwarden export format.\n", Exception::ExceptionType::BitwardenConversionError);
  }

  if (!passwords.contains("encrypted"))
  {
    throw Exception("Json must have an encrypted indicator.\n", Exception::ExceptionType::BitwardenConversionError);
  }

  if (passwords["encrypted"].is_null())
  {
    throw Exception("Encrypted value must be valid.\n", Exception::ExceptionType::BitwardenConversionError);
  }

  if (!passwords["encrypted"].is_boolean() || passwords["encrypted"] == true)
  {
    throw Exception("Encrypted value must be false.\n", Exception::ExceptionType::BitwardenConversionError);  
  }


  json_parser(passwords, buffer);  

  SecureBuffer buffer_as_secure_buffer{buffer.size()};
  std::copy(buffer.begin(), buffer.end(), buffer_as_secure_buffer.get_write_ptr());
      
  return buffer_as_secure_buffer;
}
